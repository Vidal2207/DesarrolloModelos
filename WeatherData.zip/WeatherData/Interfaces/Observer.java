package Interfaces;

public interface Observer {
    public void update(float temp,float hum,float preass);
}
